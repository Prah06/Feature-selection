import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import sys

if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} <csv>")
    sys.exit(1)

infilename = sys.argv[1]

df =  pd.read_csv(infilename, index_col='property_id')

print("Making new features...")

## Your code here
df['lot_size']=df['lot_width']*df['lot_depth']
df=df.drop(['lot_width'], axis=1)
df=df.drop(['lot_depth'], axis=1)
df['is_close_to_school'] = np.where(df['miles_to_school']<2, 1, 0)
df=df.drop(['miles_to_school'], axis=1)
df=df.iloc[:,[0,3,4,1,2]]
df=df.drop(['age_of_roof'], axis=1)


n,n1= df.values.shape
X_basic = df.values[:, :-1]
labels_basic = df.columns[:-1]
Y = df.values[:, -1]
X_basic = np.hstack([np.ones((n, 1)), X_basic])
lin_reg = LinearRegression(fit_intercept=False)


s="Using only the useful ones: ["
for i in labels_basic:
    if i==labels_basic[-1]:
        s += f"\'{i}\'" 
    else:
        s += f"\'{i}\', "

s+="]..."
print(s)


lin_reg.fit(X_basic, Y)
R2 = lin_reg.score(X_basic, Y)
print(f"R2 = {R2:f}")

print('*** Prediction ***')
B=lin_reg.coef_
str = f"Price = ${B[0]:,.2f} + "
d = len(labels_basic)
for i in range(d):
    b = B[i + 1]
    label = labels_basic[i]
    if label=='is_close_to_school':
        str += f"\nLess than 2 miles from a school? You get ${b:,.2f} added to the price!"
    else:
        str += f"({label} x ${b:,.2f})"
    if i < d - 2:
        str += " + "
print(str)
