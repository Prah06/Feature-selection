from operator import index
from re import X
import pandas as pd
import numpy as np
from sklearn.preprocessing import PolynomialFeatures
from scipy.stats import pearsonr
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import sys

# Deal with command-line
if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} <csv>")
    sys.exit(1)
infilename = sys.argv[1]

# Read in the basic data frame
df =  pd.read_csv(infilename, index_col='property_id')
X_basic = df.values[:, :-1]
labels_basic = df.columns[:-1]
Y = df.values[:, -1]

# Expand to a 2-degree polynomials
## Your code here
poly =PolynomialFeatures(degree= 2)
X_basic= poly.fit_transform(X_basic)
colname = poly.get_feature_names_out(labels_basic)
df= pd.DataFrame(X_basic)
 
# Prepare for loop
residual = Y



# We always need the column of zeros to 
# include the intercept
feature_indices = [0]

while len(feature_indices) < 3:
    col1 = []
    col2 = []
    df1=pd.DataFrame()
    for i in range(1,len(df.columns)):
        pcc,p_value = pearsonr(X_basic[:,i],residual)
        col1.append(f"\"{colname[i]}\" vs residual:")
        col2.append(f"{float(p_value)}")
    
    df1['col'] = col1
    df1['pval'] = col2
    df1['pval'] = df1['pval'].astype(float)
    df1.sort_values('pval',inplace=True)

    for i,j in zip(df1['col'],df1['pval']):
        print(f"{i} p-value ={j}")

    feature_indices.append(df1.head(1).index[0]+1)

    lin_reg = LinearRegression(fit_intercept=False)

l = []
for i in feature_indices:
    l.append(i)

X = X_basic[:,l]


lin_reg.fit(X,Y)
R2 = lin_reg.score(X,Y)

pred = lin_reg.predict(X)
residual = (Y - pred)

str ="**** Fitting with ["
for i in feature_indices:
    str += f"\"{colname[i]}\" "
str+="]****"
print(str)
print(f"R2 = {R2}")
print("Residual is updated ")

# Any relationship between the final residual and the unused variables?
print("Making scatter plot: age_of_roof vs final residual")
fig, ax = plt.subplots()
ax.scatter(X_basic[:,3], residual, marker='+')
fig.savefig("ResidualRoof.png")

print("Making a scatter plot: miles_from_school vs final residual")
fig, ax = plt.subplots()
ax.scatter(X_basic[:,4], residual, marker='+')
fig.savefig("ResidualMiles.png")

